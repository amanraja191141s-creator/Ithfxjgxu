# Micro-level audit — v98.63.9.27


## Evidence reviewed
Reference video frames show scientific buttons in a pink, unboxed function area. The latest captures showed conflicting styles and clipped options/tools.

## Corrections
- Scientific matrix is a 4×4 pink reference layout with dark readable labels, no competing button borders, and safe wrapping.
- INV state remains distinct.
- Expanded scientific functions are a 4×4 matching overlay, bounded to the panel, scrollable when needed, and includes a close key.
- Tools screen is its own scroll owner, with smaller bottom reserve and auto-height cards/labels.
- Web mirror stylesheet is synchronized and web assets build verified.
- Package/PWA/Android identity updated to 1.98.74-v98.63.9.27 / versionCode 1098075.

## Automated validation
`npm test`: 68/68 passed. `npm run build:web`: pass (13 required assets verified). ZIP integrity: pass. Main workflow and standalone YAML: byte-identical.

## Not verified
No APK was installed or run on an Android device. Gesture latency, touch reliability, viewport clipping, animation smoothness and device performance are not certified.
