# Video-matched tool rebuild — v98.63.9.36

## Scope reviewed
Reviewed the three user-provided recordings from 2026-11-22:
- `Screenrecording_20261122_171412.mp4` — Loan Calculator field entry, tenure unit toggle, validation and result panel.
- `Screenrecording_20261122_132803.mp4` — Unit Converter category/detail flow, live conversion, long-number clipping, SIP Calculator and SIP Delay Cost tabs, and tool navigation.
- `Screenrecording_20261122_115940.mp4` — Tip Calculator three-field entry with the shared keypad.

## Rebuilt flows
### Loan Calculator
- Replaced the previous prefilled loan form, Calculate button and amortization schedule screen with the recorded three-field flow: Loan Amount, Rate of Interest, Loan Tenure.
- Added Months / Years radio selection; both modes normalize to monthly periods for EMI calculation.
- Results are hidden until keypad `=` is pressed and inputs pass validation.
- Validation: minimum principal 100, annual rate 0–100%, maximum tenure 480 months / 40 years, positive integral month count.
- Result rows: Monthly Payment, Loan Amount, Interest Amount, Total Payable.
- Preserved the shared docked keypad and its `=` action.

### SIP Calculator
- Added the missing SIP Delay Cost tab and four-field delay form.
- Standard SIP calculation retained as the first tab.
- Delay comparison reports the future value when starting today, the future value after the chosen delay, and the difference as Loss / Cost of Delay.
- Delay is limited to 0–12 months; the keypad blocks values above 12.
- Uses monthly compounding and month-end deposits for the illustrative projection; no guaranteed-return claim is made.

### Tip Calculator
- Replaced preset/custom-tip controls and hidden tax/person fields with the recorded Bill Amount, Rate of Tip and Number of Person fields.
- Removed obsolete preset and tax-toggle event wiring.
- Calculates tip amount, total amount and per-person share, with invalid/empty input protection.

### Unit Converter
- Kept the category chooser and live conversion flow.
- Hid the redundant category dropdown from the converter detail screen while retaining its internal category state.
- Removed the redundant Convert button; changing the value or units updates the result live.
- Added constrained responsive result typography, wrapping and overflow handling for large converted values.

## Regression and integrity checks
- `node --check assets/js/app.js`: PASS.
- `npm run build:web`: PASS; 13 required web assets verified and mirrored.
- `npm run test:release`: PASS; 59 tests, 59 passed, 0 failed.
- CSS parser: 0 parse errors.
- HTML duplicate IDs: none.
- Source / `www` HTML, CSS and JS parity: PASS.
- Standalone Android workflow YAML parses successfully.
- Root workflow and `.github/workflows/main.yml` are byte-identical.
- Release identity: `1.98.78-v98.63.9.36`, Android versionCode `1098084`.

## Validation limits
A browser-based visual run and Android device / emulator test were not completed in this environment. Therefore this report does not certify pixel-perfect rendering on every Android screen, physical-device touch feel, frame-time performance, or an APK build. The included GitHub Actions workflow is configured to build and verify the Android package when run in GitHub Actions.
