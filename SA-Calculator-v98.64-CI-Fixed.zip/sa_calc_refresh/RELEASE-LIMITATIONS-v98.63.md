# Release limitations — v98.63.2

- This deliverable is the Android-ready web source and workflow YAML, not a prebuilt APK.
- No physical Android device installation or screenshot/video replay was performed after the fixes.
- Automated source tests do not certify lag-free behavior, battery/memory use, or compatibility with every Android WebView/OEM keyboard.
- Currency conversion depends on live provider/network availability and provider rate freshness.
- The new service-worker cache namespace forces the updated offline web assets to be fetched after the updated source/app is deployed; a previously installed native APK must still be updated/reinstalled with a newly built APK to receive packaged changes.
