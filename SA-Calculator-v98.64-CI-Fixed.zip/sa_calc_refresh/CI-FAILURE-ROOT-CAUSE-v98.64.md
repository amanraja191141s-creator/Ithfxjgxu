# CI failure root-cause and repair — v98.64

## Confirmed failure

The v98.64 workflow's source preflight listed two test paths that did not exist in the release archive:

- `tests/v9864-full-width-tool-keypad.test.mjs`
- `tests/action-workflow-preflight-v9864.test.mjs`

The actual release tests are:

- `tests/v9863936-full-width-tool-keypad.test.mjs`
- `tests/action-workflow-preflight-v9863936.test.mjs`

Because the workflow uses `set -e` and checks every required file, source verification exited immediately. GitHub Actions consequently skipped later steps (SDK verification, npm installation, web build, regression suite, Capacitor sync and APK build). This matches the supplied run log where later steps show 0 seconds.

## Repairs

1. Updated the workflow source-preflight file list to the real v98.64 test filenames.
2. Updated the workflow preflight regression test to assert the real paths.
3. Corrected the stale workflow step label from v98.63 to v98.64.
4. Synchronized `.github/workflows/main.yml` and `Android-Workflow-v98.64.yml` byte-for-byte.
5. Kept release identity and Android version code unchanged.

## Local verification

- `npm run test:release`: **65/65 passed**.
- Targeted workflow preflight + full-width keypad tests: **15/15 passed**.
- JavaScript syntax checks: passed.
- Android web bundle preparation: passed; 13 required assets verified.
- Workflow YAML parsed successfully.
- Workflow mirror: byte-identical.
- ZIP integrity: verified after packaging.

## Remaining CI/device checks

A complete hosted GitHub Actions run is still required to verify remote dependency installation, Android SDK setup, Capacitor generation/sync, Gradle compilation, APK metadata and artifact upload. Physical Android installation/performance is not tested by this local source audit.
