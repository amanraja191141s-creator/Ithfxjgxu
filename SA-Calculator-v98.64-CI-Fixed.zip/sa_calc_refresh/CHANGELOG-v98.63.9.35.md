# v98.63.9.35 — Android WebView keypad layout and Actions preflight

- Rebuilt the shared tool keypad as an app-container-anchored bottom dock.
- Replaced viewport-fixed sizing with a width-constrained flex/grid layout to prevent the full-width panel from containing a tiny intrinsic-size keypad.
- Removed the square aspect-ratio constraint from tool keypad buttons so each cell stretches to its grid track.
- Added compact-height and landscape sizing rules while preserving the 4-column / 4-row key arrangement and tall equals key.
- Kept the main calculator and dedicated hexadecimal keypad separate.
- Rotated the service-worker cache namespace and aligned release metadata, Android versionCode, and Actions checks.
- Added regression tests for dock anchoring, stretch sizing, release identity, and workflow/cache consistency.
