import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
const html=fs.readFileSync('index.html','utf8'), js=fs.readFileSync('assets/js/app.js','utf8'), css=fs.readFileSync('assets/css/app.css','utf8');
test('scientific matrix follows the pink reference primary functions plus the extended secondary bank',()=>{
 const grid=html.match(/<div class="scientific-function-grid"[\s\S]*?<\/div>/)?.[0]||'';
 const expected=['sin(','cos(','tan(','ln(','log(','abs(','fact(','pi','2.718281828459045','sqrt(','10^(','^2','^'];
 for(const token of expected) assert.ok(grid.includes(`data-sci-insert="${token}"`),`missing primary function ${token}`);
 for(const label of ['INV','sin','cos','tan','ln','log','|x|','x!','π','e','eˣ','√','10ˣ','x²','xʸ']) assert.ok(grid.includes(`>${label}<`),label);
 const more=html.match(/<div class="scientific-more-functions"[\s\S]*?<\/div>/)?.[0]||'';
 for(const token of ['sinh(','cosh(','tanh(','asinh(','acosh(','atanh(','cbrt(','2^(','^(-','log2(','i']) assert.ok(more.includes(`data-sci-insert="${token}"`),token);
 for(const label of ['sinh','cosh','tanh','sinh⁻¹','cosh⁻¹','tanh⁻¹','∛','2ˣ','x³','x⁻ʸ','log₂','i']) assert.ok(more.includes(`>${label}<`),label);
 assert.equal((grid.match(/<button\b/g)||[]).length,16);
 assert.match(css,/v98\.63\.9\.26 — recording alignment/);
});
test('scientific parser accepts inverse-hyperbolic functions and complex unit is explicit about unsupported calculation',()=>{
 for(const fn of ['asinh','acosh','atanh']) assert.ok(js.includes(`case '${fn}'`),fn);
 assert.match(js,/token === 'i'[\s\S]*?Complex-number calculations are not supported yet/);
});
test('recording tools order includes Finance & Money, Math & General Utilities and separate Age/BMI tiles',()=>{
 const tools=html.slice(html.indexOf('id=\"premium-tools-grid\"'),html.indexOf('id=\"premium-tools-grid\"')+12000);
 for(const label of ['GST/VAT','Loan','Saving','Salary','Tip','SIP','Currency','Discount','Percentage','Unit','Age','BMI']) assert.ok(tools.includes(`>${label}<`),label);
 assert.match(html,/id=\"screen-salary\"/); assert.match(html,/id=\"screen-sip\"/); assert.match(html,/id=\"screen-agecalc\"/);
 assert.match(js,/function calcSalary\(/); assert.match(js,/function calcSIP\(/); assert.match(js,/function calcAge\(/);
});
test('salary and SIP calculators validate ranges and avoid NaN/infinite result display',()=>{
 assert.match(js,/pct < 0 \|\| pct > 100/);
 assert.match(js,/rate > 1000 \|\| years <= 0 \|\| years > 100/);
 assert.match(js,/!\[value,invested,growth\]\.every\(Number\.isFinite\)/);
});
test('Age calculator rejects future dates and responds to date field and calculate action',()=>{
 assert.match(js,/birth>today/); assert.match(js,/age-date-of-birth[\s\S]*?addEventListener\('change', calcAge\)/);
 assert.match(html,/id=\"age-calculate\"/);
});

test('salary take-home and SIP projections calculate deterministically for representative inputs',()=>{
 const salary=js.match(/function calcSalary\(\)\s*\{[\s\S]*?\n\}/)?.[0];
 const sip=js.match(/function calcSIP\(\)\s*\{[\s\S]*?\n\}/)?.[0];
 assert.ok(salary&&sip);
 const values={'salary-gross':1000,'salary-deduction':20,'sip-monthly':500,'sip-rate':12,'sip-years':1};
 const results={}; const nodes={};
 for(const [id,val] of Object.entries(values)) nodes[id]={querySelector:()=>({textContent:String(val)})};
 const context={Math,Number,document:{getElementById:id=>nodes[id]||null},readModuleNumber:id=>Number(values[id]),formatResultNumber:n=>Number(n).toFixed(2),setElementText:(id,text)=>results[id]=text};
 vm.runInNewContext(`${salary};${sip};calcSalary();calcSIP();`,context);
 assert.equal(results['salary-net'],'₹ 800.00'); assert.equal(results['salary-annual'],'₹ 9600.00');
 const expected=500*((Math.pow(1+0.12/12,12)-1)/(0.12/12));
 assert.ok(Math.abs(Number(results['sip-value'].replace('₹ ',''))-expected)<0.01);
 assert.equal(results['sip-invested'],'₹ 6000.00');
});

test('inverse hyperbolic numeric functions produce correct scalar values',()=>{
 const helper=js.match(/function applyScientificFunction\(name, value\)\s*\{[\s\S]*?\n  \}/)?.[0];
 assert.ok(helper); const ctx={Math,finite:n=>n,angleMode:'rad'};
 vm.runInNewContext(`${helper};globalThis.run=applyScientificFunction`,ctx);
 assert.ok(Math.abs(ctx.run('asinh',1)-Math.log(1+Math.sqrt(2)))<1e-12);
 assert.ok(Math.abs(ctx.run('acosh',2)-Math.log(2+Math.sqrt(3)))<1e-12);
 assert.ok(Math.abs(ctx.run('atanh',0.5)-Math.log(3)/2)<1e-12);
});
