'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const source = fs.readFileSync(path.join(__dirname, '..', 'assets/js/app.js'), 'utf8');
function extract(name) {
  const start = source.indexOf(`function ${name}(`);
  assert.notEqual(start, -1, `${name} not found`);
  const open = source.indexOf('{', start); let depth = 0;
  for (let i = open; i < source.length; i++) {
    if (source[i] === '{') depth++;
    else if (source[i] === '}' && --depth === 0) return source.slice(start, i + 1);
  }
  throw new Error(`Could not extract ${name}`);
}
function makeElement(id, values, outputs) {
  const classes = new Set();
  return {
    id, value: values[id] == null ? '' : String(values[id]), textContent: '', dataset: {},
    style: {}, checked: Boolean(values[id]),
    classList: { add: name => classes.add(name), remove: name => classes.delete(name), contains: name => classes.has(name) },
    querySelector: selector => selector === '.input-text' ? { textContent: String(values[id] ?? '') } : null,
    setAttribute() {}, getAttribute() { return null; },
    replaceChildren() {}, appendChild() {},
    _classes: classes
  };
}

test('financial and utility calculators return expected values for representative cases', () => {
  const values = {
    'disc-tax': 10, 'disc-orig': 100, 'disc-pct': 20,
    'pct-init': 200, 'pct-final': 250, 'pct-x': 20, 'pct-y': 300,
    'tax-rate': 10, 'tax-orig': 100, 'tax-mode': 'exclusive',
    'bmi-height': 180, 'bmi-weight': 80, 'bmi-age': 30, 'bmi-gender': 'male',
    'fc-dist': 100, 'fc-eff': 10, 'fc-price': 100,
    'fe-before': 20, 'fe-after': 10, 'fe-added': 30, 'fe-dist': 400,
    'sav-p': 1000, 'sav-monthly': 100, 'sav-r': 5, 'sav-m': 2, 'sav-tax': 10, 'sav-frequency': 'simple',
    'tip-bill': 110, 'tip-pct': 10, 'tip-people': 2, 'tip-tax': 10, 'tip-exclude-tax': true,
    'up-p-a': 10, 'up-q-a': 1, 'up-p-b': 20, 'up-q-b': 4,
    'up-p-c': '', 'up-q-c': '', 'up-p-d': '', 'up-q-d': ''
  };
  const outputs = {};
  const elements = new Map();
  const get = id => { if (!elements.has(id)) elements.set(id, makeElement(id, values, outputs)); return elements.get(id); };
  const rows = ['A','B','C','D'].map(key => get(`up-row-${key}`));
  const document = {
    getElementById: id => get(id),
    querySelector: selector => selector === '#bmi-gender' ? get('bmi-gender') : null,
    querySelectorAll: selector => selector === '.unit-price-grid' ? rows : []
  };
  const context = {
    document, Number, Math, Intl,
    readModuleNumber: id => values[id] === '' || values[id] == null ? NaN : Number(values[id]),
    setElementText: (id, value) => { outputs[id] = String(value); get(id).textContent = String(value); },
    formatResultNumber: value => String(Math.round(Number(value) * 100) / 100),
    STATE: { precision: 'auto', thousandsSep: 'comma' }
  };
  const names = ['calcDiscount','calcPercent','calcSalesTax','calcBodyMetrics','calcFuelCost','calcFuelEfficiency','calcSavings','calcTip','calcUnitPrice'];
  vm.runInNewContext(`${names.map(extract).join('\n')};${names.map(n=>`globalThis.${n}=${n};`).join('')}`, context);
  names.forEach(name => context[name]());
  assert.equal(outputs['disc-saved'], '₹ 20');
  assert.equal(outputs['disc-final'], '₹ 88');
  assert.equal(outputs['pct-change-res'], '+25%');
  assert.equal(outputs['pct-xy-res'], '60');
  assert.equal(outputs['tax-amt'], '₹ 10');
  assert.equal(outputs['tax-total'], '₹ 110');
  assert.ok(Math.abs(Number(outputs['bmi-val']) - 24.69) < 0.001);
  assert.equal(outputs['bmr-val'], '1780 kcal');
  assert.equal(outputs['fc-fuel-res'], '10 L');
  assert.equal(outputs['fc-cost-res'], '$ 1000');
  assert.equal(outputs['fe-consumed-res'], '40 L');
  assert.equal(outputs['fe-kml-res'], '10 km/L');
  assert.equal(outputs['fe-l100-res'], '10 L/100km');
  assert.equal(outputs['fe-mpg-res'], '23.52 mpg');
  assert.equal(outputs['sav-int-res'], '₹ 193.5');
  assert.equal(outputs['sav-bal-res'], '₹ 3593.5');
  assert.equal(outputs['tip-amt-res'], '₹ 11');
  assert.equal(outputs['tip-tot-res'], '₹ 121');
  assert.equal(outputs['tip-per-res'], '₹ 60.5');
  assert.equal(outputs['tip-per-tip-res'], '₹ 5.5');
  assert.equal(outputs['up-u-a'], '10');
  assert.equal(outputs['up-u-b'], '5');
  assert.match(outputs['up-best-banner'], /Item 2/);
});


test('tip calculator exposes all four video-reference totals with per-person tip separated', () => {
  const values = { 'tip-bill': 956, 'tip-pct': 2, 'tip-people': 26 };
  const outputs = {};
  const elements = new Map();
  const get = id => {
    if (!elements.has(id)) elements.set(id, {
      textContent: '', querySelector: selector => selector === '.input-text' ? { textContent: String(values[id] ?? '') } : null
    });
    return elements.get(id);
  };
  const document = { getElementById: get };
  const context = {
    document, Number, Math,
    readModuleNumber: id => Number(values[id]),
    formatResultNumber: value => (Math.round(value * 100) / 100).toFixed(2),
    setElementText: (id, value) => { outputs[id] = String(value); }
  };
  vm.runInNewContext(`${extract('calcTip')};globalThis.calcTip=calcTip;`, context);
  context.calcTip();
  assert.equal(outputs['tip-per-res'], '₹ 37.50');
  assert.equal(outputs['tip-amt-res'], '₹ 19.12');
  assert.equal(outputs['tip-per-tip-res'], '₹ 0.74');
  assert.equal(outputs['tip-tot-res'], '₹ 975.12');
});

test('video-matched loan calculator computes EMI from amount, rate and month/year tenure', () => {
  const values = { 'loan-p': 1000, 'loan-r': 12, 'loan-tenure': 12 };
  const outputs = {};
  const result = { hidden: true };
  const screen = { dataset: { loanSubmitted: 'true' } };
  const elements = new Map();
  const get = id => {
    if (!elements.has(id)) elements.set(id, { textContent: String(values[id] ?? ''), hidden: false });
    return elements.get(id);
  };
  const document = {
    getElementById: id => id === 'screen-loan' ? screen : id === 'loan-results' ? result : get(id),
    querySelector: selector => {
      if (selector === 'input[name="loan-tenure-unit"]:checked') return { value: 'months' };
      const match = selector.match(/^#(.+) \.input-text$/);
      return match ? { textContent: String(values[match[1]] ?? '') } : null;
    }
  };
  const context = {
    document, Number, Math,
    readModuleNumber: id => Number(values[id]),
    formatResultNumber: value => Number(value).toFixed(2),
    showToast: () => {},
    setElementText: (id, value) => { outputs[id] = String(value); }
  };
  vm.runInNewContext(`${extract('calcLoan')};globalThis.calcLoan=calcLoan;`, context);
  context.calcLoan();
  assert.equal(result.hidden, false);
  assert.equal(outputs['loan-monthly'], '88.85');
  assert.equal(outputs['loan-principal-result'], '1000.00');
  assert.equal(outputs['loan-total'], '1066.19');
  assert.ok(Number(outputs['loan-interest']) > 0);

  // The same 12-month period expressed as one year must produce the same EMI.
  document.querySelector = selector => {
    if (selector === 'input[name="loan-tenure-unit"]:checked') return { value: 'years' };
    const match = selector.match(/^#(.+) \.input-text$/);
    return match ? { textContent: String(values[match[1]] ?? '') } : null;
  };
  values['loan-tenure'] = 1;
  context.calcLoan();
  assert.equal(outputs['loan-monthly'], '88.85');

  values['loan-p'] = 99;
  context.calcLoan();
  assert.equal(result.hidden, true);
});



test('SIP delay-cost mode compares starting today with a delayed start and enforces the 12-month cap', () => {
  const values = { 'sip-delay-monthly': 988, 'sip-delay-years': 8, 'sip-delay-rate': 9, 'sip-delay-months': 9 };
  const outputs = {};
  const labels = {};
  const screen = { dataset: { sipMode: 'delay' } };
  const document = {
    getElementById: id => {
      if (id === 'screen-sip') return screen;
      if (Object.prototype.hasOwnProperty.call(values, id)) return { querySelector: () => ({ textContent: String(values[id]) }) };
      return (labels[id] ||= { textContent: '' });
    },
    querySelector: selector => {
      const match = selector.match(/^#(.+) \.input-text$/);
      return match ? { textContent: String(values[match[1]] ?? '') } : null;
    }
  };
  const context = {
    document, Number, Math,
    readModuleNumber: id => Number(values[id]),
    formatResultNumber: value => Number(value).toFixed(2),
    setElementText: (id, value) => { outputs[id] = String(value); },
    showToast: message => { outputs.toast = message; }
  };
  vm.runInNewContext(`${extract('calcSIP')};globalThis.calcSIP=calcSIP;`, context);
  context.calcSIP();
  assert.equal(labels['sip-result-label-one'].textContent, 'If you start today');
  assert.equal(labels['sip-result-label-two'].textContent, 'If you start after 9 months');
  assert.equal(labels['sip-result-label-three'].textContent, 'Loss / Cost of Delay');
  assert.equal(outputs['sip-value'], '₹ 138177.89');
  assert.equal(outputs['sip-invested'], '₹ 120623.72');
  assert.equal(outputs['sip-growth'], '₹ 17554.17');
  assert.equal(outputs['sip-today-value'], '₹ 11013.70');
  assert.equal(labels['sip-today-value-row'].hidden, false);

  values['sip-delay-months'] = 13;
  context.calcSIP();
  assert.match(outputs.toast, /12 Months/);
});

test('date-event recurrence uses UTC calendar arithmetic and Feb 29 fallback', () => {
  const start = source.indexOf('function dateEventDays(');
  const open = source.indexOf('{', start); let depth = 0, end = -1;
  for (let i = open; i < source.length; i++) { if (source[i] === '{') depth++; else if (source[i] === '}' && --depth === 0) { end = i + 1; break; } }
  const context = { Date, Math };
  vm.runInNewContext(`${source.slice(start, end)};globalThis.days=dateEventDays;`, context);
  assert.equal(context.days({ date: '2000-02-29', repeat: false }, new Date('2025-03-01T12:00:00Z')), -9132);
  assert.equal(context.days({ date: '2000-02-29', repeat: true }, new Date('2025-03-01T12:00:00Z')), 364);
});

test('unit, date, hexadecimal and world-time helpers cover conversion and boundary cases', () => {
  const UNIT_DATA = {
    length: { units: { 'Meter (m)': 1, 'Centimeter (cm)': 0.01 } },
    temperature: { units: { 'Celsius (°C)': 1, 'Fahrenheit (°F)': 1, 'Kelvin (K)': 1 } },
    fuel: { units: { 'Kilometers per liter (km/L)': 1, 'Liters per 100 km (L/100 km)': 1, 'Miles per US gallon (mpg US)': 1 } }
  };
  const context = { UNIT_DATA, Number, Math, Date, Intl, BigInt, String };
  vm.runInNewContext(`${extract('convertUnitValue')};${extract('validISODate')};${extract('hexCurrentBigInt')};${extract('worldTimeDateTimeValue')};let hexBase=16,hexDigits='FFFFFFFF';globalThis.convert=convertUnitValue;globalThis.valid=validISODate;globalThis.hex=hexCurrentBigInt;globalThis.world=worldTimeDateTimeValue;`, context);
  assert.equal(context.convert('length', 2, 'Meter (m)', 'Centimeter (cm)'), 200);
  assert.equal(context.convert('temperature', 32, 'Fahrenheit (°F)', 'Celsius (°C)'), 0);
  assert.equal(context.convert('temperature', -273.15, 'Celsius (°C)', 'Kelvin (K)'), 0);
  assert.ok(Number.isNaN(context.convert('temperature', -1, 'Kelvin (K)', 'Celsius (°C)')));
  assert.ok(Number.isNaN(context.convert('temperature', -300, 'Celsius (°C)', 'Kelvin (K)')));
  assert.equal(context.convert('fuel', 10, 'Kilometers per liter (km/L)', 'Liters per 100 km (L/100 km)'), 10);
  assert.equal(context.valid('2024-02-29'), true);
  assert.equal(context.valid('2025-02-29'), false);
  assert.equal(context.hex().toString(), '4294967295');
  assert.match(context.world('Asia/Kolkata', new Date('2026-11-13T00:00:00Z')), /^2026-11-13T/);
});

test('weighted GPA ignores empty/zero-credit rows and uses credit-weighted grade points', () => {
  const outputs = {};
  const rows = [
    { querySelector: selector => selector === '.gpa-credits' ? { value: '3' } : selector === '.gpa-grade' ? { value: '4' } : null },
    { querySelector: selector => selector === '.gpa-credits' ? { value: '1' } : selector === '.gpa-grade' ? { value: '2' } : null },
    { querySelector: selector => selector === '.gpa-credits' ? { value: '0' } : selector === '.gpa-grade' ? { value: '4' } : null },
    { querySelector: selector => selector === '.gpa-credits' ? { value: '' } : selector === '.gpa-grade' ? { value: '3' } : null }
  ];
  const context = {
    document: { querySelectorAll: selector => selector === '#gpa-rows .gpa-course-row' ? rows : [] },
    Number, Math,
    formatResultNumber: value => Number(value).toFixed(2),
    showToast: () => {},
    setElementText: (id, value) => { outputs[id] = String(value); }
  };
  vm.runInNewContext(`${extract('calcGpa')};globalThis.run=calcGpa;`, context);
  context.run();
  assert.equal(outputs['gpa-credits-res'], '4.00');
  assert.equal(outputs['gpa-val-res'], '3.50');
});
