import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read = p => fs.readFileSync(p, 'utf8');

test('v98.50 scientific reference proportions, legends and five-column numeric grid are present', () => {
  const html = read('index.html');
  const start = html.indexOf('class="scientific-function-grid"');
  const end = html.indexOf('class="scientific-more-functions"', start);
  const functions = html.slice(start, end);
  assert.equal((functions.match(/data-sci-insert=/g) || []).length, 18);
  assert.equal((functions.match(/data-sci-hint=/g) || []).length, 18);
  for (const hint of ['SHIFT: sin⁻¹','SHIFT: cos⁻¹','SHIFT: tan⁻¹','SHIFT: log₂','SHIFT: eˣ']) assert.ok(functions.includes(hint));
  const css = read('assets/css/app.css');
  assert.match(css, /scientific-function-grid\s*\{[\s\S]*?grid-template-columns:repeat\(6,minmax\(0,1fr\)\)/);
  assert.match(css, /scientific-keypad\s*\{[\s\S]*?grid-template-columns:repeat\(5,minmax\(0,1fr\)\)/);
  assert.match(css, /scientific-keypad\s*\{[\s\S]*?grid-template-rows:repeat\(4,minmax\(52px,1fr\)\)/);
  assert.match(css, /scientific-display[\s\S]*?background:linear-gradient/);
  assert.match(css, /scientific-function-grid button::before[\s\S]*?attr\(data-sci-hint\)/);
});

test('basic calculator visual refinement keeps minimum touch target and avoids transformed hit areas', () => {
  const css = read('assets/css/app.css');
  assert.match(css, /#screen-calc\.active > \.main-keypad > button\.key-btn[\s\S]*?min-height:40px/);
  assert.doesNotMatch(css, /#screen-calc\.active > \.main-keypad > button\.key-btn\s*\{[^}]*transform:scale/);
});

test('v98.50 release workflow and offline cache are synchronized', () => {
  const pkg = JSON.parse(read('package.json'));
  const manifest = JSON.parse(read('manifest.webmanifest'));
  const sw = read('service-worker.js');
  const workflow = read('.github/workflows/main.yml');
  const standalone = read('.github/workflows/main.yml');
  assert.equal(pkg.version, '1.98.65-v98.63.9.17');
  assert.equal(manifest.version, pkg.version);
  assert.match(sw, /sa-calculator-v98-63-10-clean-runtime-v9863917/);
  assert.match(workflow, /SA_EXPECTED_VERSION: '1\.98\.65-v98\.63\.9\.17'/);
  assert.match(workflow, /versionCode='1098065'/);
  assert.equal(workflow, standalone);
  assert.ok(fs.existsSync('assets/css/app.css'));
});
