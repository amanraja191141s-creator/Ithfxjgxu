const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const js = fs.readFileSync(path.join(root, 'assets/js/app.js'), 'utf8');
const inventory = JSON.parse(fs.readFileSync(path.join(root, 'design-reference/18-screen-inventory.json'), 'utf8'));
const allowed = ['salestax','loan','savings','salary','tip','sip','currencies','discount','percent','units','agecalc','bodymetrics'];

test('Tools catalogue exposes exactly the 12 requested tools', () => {
  const cards = [...html.matchAll(/data-tool-screen="([^"]+)"/g)].map(m => m[1]);
  assert.deepEqual(cards, allowed);
  assert.equal(new Set(cards).size, 12);
});

test('Startup picker and favorites are restricted to the requested tool set', () => {
  const select = html.match(/<select class="settings-select" id="setting-startup-screen"[\s\S]*?<\/select>/)?.[0] || '';
  for (const id of allowed) assert.match(select, new RegExp(`value="${id}"`));
  for (const id of ['date','fuelcost','fuelefficiency','gradeavg','hex','unitprice','worldtime']) assert.doesNotMatch(select, new RegExp(`value="${id}"`));
  const favBlock = js.match(/const ALL_CALC_ITEMS = \[[\s\S]*?\n\];/)?.[0] || '';
  for (const id of allowed) assert.match(favBlock, new RegExp(`id: '${id}'`));
  for (const id of ['date','fuelcost','fuelefficiency','gradeavg','hex','unitprice','worldtime']) assert.doesNotMatch(favBlock, new RegExp(`id: '${id}'`));
});

test('All requested tool destinations and calculation handlers exist', () => {
  for (const id of allowed) assert.match(html, new RegExp(`id="screen-${id}"`));
  for (const fn of ['calcSalesTax','calcLoan','calcSavings','calcSalary','calcTip','calcSIP','calcCurrency','calcDiscount','calcPercent','calcUnits','calcAge','calcBodyMetrics']) {
    assert.match(js, new RegExp(`function ${fn}\\s*\\(`));
  }
});

test('Saving calculator supports initial deposit plus monthly contributions and bounded inputs', () => {
  assert.match(html, /id="sav-monthly"/);
  assert.match(js, /const monthlyContribution = monthlyField \? read\('sav-monthly'\) : 0/);
  assert.match(js, /const totalContributions = monthlyContribution \* months/);
  assert.match(js, /const contributionValue = months === 0/);
  assert.match(js, /taxPct > 100/);
});

test('Tool inventory lists only the requested 12 tools', () => {
  assert.deepEqual(inventory.filter(x => x.kind === 'tool').map(x => x.id), allowed);
  assert.match(js, /birth\.getFullYear\(\) !== year \|\| birth\.getMonth\(\) !== month - 1 \|\| birth\.getDate\(\) !== day/);
});
