# v98.64 CI hotfix

- Fixed the early CI failure caused by stale/nonexistent test paths in the source preflight.
- Aligned workflow preflight assertions with the actual v98.64 regression test filenames.
- Corrected the stale v98.63 workflow step label.
- Kept source version `1.98.79-v98.64` and Android versionCode `1098085`.
- Verified release suite: 65/65 passing.
