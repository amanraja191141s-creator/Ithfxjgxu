# Micro-level audit — v98.63.9.25

## Scope
Scientific keypad `＋` expansion and collapse interaction, visual consistency, accessibility state, Escape handling, release identity and Android workflow synchronization.

## Findings and corrections
1. The expansion toggle retained a plus glyph while the additional-function layer was open, making the control state ambiguous. It now changes to `×` and updates its accessible name and `aria-expanded` state.
2. Escape previously closed the scientific drawer directly. It now closes the expanded functions first, restores focus to the toggle and preserves the current expression; a subsequent Escape closes the drawer.
3. Closing the drawer now resets the hidden panel, glyph, accessible name and expanded state together, preventing a stale expanded state on the next open.
4. The expanded panel uses the same flat pink background and borderless transparent text keys as the primary scientific matrix. No extra labels, card chrome, helper text or duplicate keypad are displayed.
5. Scientific function insertion remains routed through `insertScientificIntoMain`; INV, memory and calculator expression behavior are retained.

## Release identity
- Package/app version: `1.98.72-v98.63.9.25`
- Android versionCode: `1098073`
- Service worker cache: `sa-calculator-v98-63-11-clean-runtime-v9863925-scientific-more-clean-expand`

## Limits
Automated source tests and web-bundle validation do not certify physical-device touch latency, OEM gesture behavior, or visual parity on every Android screen size. The final hosted Gradle APK build must be confirmed by running the included GitHub Actions workflow.
