# Tool catalogue scope correction — v98.63.9.36

## Exact tool set

The visible Tools catalogue, startup-screen picker, favorites manager and reference inventory are now aligned to exactly these 12 tools:

1. GST
2. Loan
3. Saving
4. Salary
5. Tip
6. SIP
7. Currency Converter
8. Discount
9. Percentage
10. Unit Converter
11. Age
12. BMI

The calculator, scientific calculator, history, favorites and settings remain core app surfaces and are not counted as tools. Extra utilities (Date, Fuel Cost, Fuel Efficiency, Grade Average, Number Base/Hex, Unit Price and World Time) are removed from the user-facing Tools catalogue, startup picker and favorites selector. Their legacy implementation files/screens are retained internally to avoid unsafe deletion of shared code; they are not exposed as tools.

## Saving calculator correction

Added a monthly-contribution input alongside the initial deposit. Projection now includes the initial deposit, end-of-month monthly contributions, selected compounding convention, duration, and tax on interest. Invalid/negative inputs and out-of-range calculations are handled without emitting non-finite results. Currency display is INR for the Saving results.

## Validation

Added regression coverage for exact catalogue membership, startup picker membership, favorites membership, screen/handler presence, and monthly-contribution savings behavior. Source-level tests do not replace physical Android-device testing or APK installation checks.

## Follow-up consistency and validation fixes

- GST, Discount, Saving and Tip monetary results now use INR (₹), matching the Indian-facing tool presentation; Salary and SIP already use INR.
- Simple-interest savings contributions accrue simple interest by remaining month count; compound modes use the selected compounding convention converted to an equivalent monthly rate for month-end deposits.
- Age Calculator now rejects impossible calendar dates (for example, an invalid day rolled into the following month) as well as future dates.
