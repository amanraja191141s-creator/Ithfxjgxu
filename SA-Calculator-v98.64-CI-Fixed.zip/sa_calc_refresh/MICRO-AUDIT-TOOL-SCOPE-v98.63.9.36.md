# Micro audit — exact 12-tool scope

## User-requested catalogue

| # | Tool | Screen ID | Handler |
|---:|---|---|---|
| 1 | GST | salestax | calcSalesTax |
| 2 | Loan | loan | calcLoan |
| 3 | Saving | savings | calcSavings |
| 4 | Salary | salary | calcSalary |
| 5 | Tip | tip | calcTip |
| 6 | SIP | sip | calcSIP |
| 7 | Currency Converter | currencies | calcCurrency |
| 8 | Discount | discount | calcDiscount |
| 9 | Percentage | percent | calcPercent |
| 10 | Unit Converter | units | calcUnits |
| 11 | Age | agecalc | calcAge |
| 12 | BMI | bodymetrics | calcBodyMetrics |

## Scope enforcement

- Tools screen contains exactly 12 cards.
- Search/category filtering works only across those 12 cards.
- Startup preferences contain Calculator plus the 12 tools and Resume Last Used Screen.
- Favorites manager contains Calculator plus the 12 tools; stale saved favorites are filtered against this list.
- Extra utilities are absent from the catalogue, startup selector, favorites selector and current reference inventory.
- Core calculator, scientific calculator, history, favorites and settings remain intact.

## Functional notes

- GST supports tax-added and tax-inclusive modes; the tax rate is constrained to 0–100% and results use INR display.
- Loan EMI validates principal, rate and tenure, including the 40-year cap and month/year selection.
- Saving now supports initial deposit plus monthly contributions, duration, compounding and tax on interest.
- Salary estimates monthly and annual take-home from gross salary and deduction percentage; this is an estimate, not payroll tax advice.
- Tip reports total tip, per-person tip, total bill and per-person amount.
- SIP supports monthly investment projections and its delay-cost mode; outputs are projections, not guaranteed returns.
- Currency conversion uses the existing exchange-rate provider/cache and selectable currency pair.
- Discount, Percentage and Unit Converter retain their existing dedicated input and result systems.
- Age validates future dates and computes years/months/days.
- BMI validates height, weight and age; BMR requires explicit sex selection and uses Mifflin–St Jeor.

## Verification boundary

The new tests validate source-level wiring and exact catalogue membership. Real-device rendering, touch latency, offline/online currency freshness, APK assembly and installation must still be run in Android CI/device testing before claiming a fully bug-free release.
