# Independent micro-level audit — v98.63.9.36

## Scope
Inspected the uploaded `SA-Calculator-v98.63.9.36-Video-UI-Rebuild.zip` source tree and the separately uploaded `SA-Calculator-v98.63.9.36-Android-Workflow.yml`. Reviewed release metadata, tool-flow change notes, QA report, workflow mirrors, package scripts, web bundle generation and regression test definitions.

## Confirmed checks
- `node --check assets/js/app.js`: PASS.
- `npm run build:web`: PASS; 13 required Android web assets verified and mirrored.
- `npm run test:release`: PASS; 59 tests, 59 passed, 0 failed.
- Workflow copies: standalone YAML, root workflow and `.github/workflows/main.yml` are byte-identical (15,803 bytes).
- ZIP source archive: extracted and inspected successfully.
- Release identity: package `1.98.78-v98.63.9.36`, Android versionCode `1098084`.

## Findings and corrections
1. README release heading and opening release description were stale at v98.63.9.32 despite the package and workflow being v98.63.9.36. Updated README release identity and added a current-release verification block.
2. Historical `npm run test:legacy` is not a green release gate: observed 516 tests, 387 passed and 129 failed. Failures include tests pinned to old release versions/workflow filenames (for example v98.63.9.33/v98.63.9.34 and a missing v98.63.9.32 workflow file), plus legacy assertions for superseded behavior. The current package explicitly defines `test:release` as the release gate. These historical failures were not silently deleted or reclassified as passes.
3. `npm install --ignore-scripts --no-audit --no-fund` did not complete within the available execution window. The already-present runtime was sufficient to execute the release tests and web build; dependency installation and a full Gradle build were not certified here.

## Video flow coverage represented in source/tests
- Loan: amount, annual rate, tenure, Months/Years normalization, validation and EMI summary.
- SIP: standard projection and Delay Cost comparison, with 0–12 month delay limit.
- Tip: bill amount, tip rate, people count, tip/total/per-person outputs.
- Unit converter: category/detail flow, live conversion and long-result overflow handling.
- Shared docked numeric keypad remains the common tool input surface.

## Not certified in this environment
- Pixel-perfect browser or Android-device visual rendering.
- Physical-device touch/scroll behavior, frame-time performance, memory/battery use or OEM keyboard compatibility.
- APK generation, installation, signing or emulator/device runtime.
- Live currency/network provider behavior.

## Release recommendation
The focused v98.63.9.36 source gate and web bundle pass. Treat this as a source-verified web package, not a device-certified APK. Run the included GitHub Actions workflow or a local Android SDK/Gradle build, then perform physical-device visual and interaction checks before public release.
